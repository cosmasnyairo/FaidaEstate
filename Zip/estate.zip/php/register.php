<?php
     session_start();
     $db = mysqli_connect('localhost', 'root', '', 'estate');
   
	$update = false;
 
      if(isset($_POST['save'])) {
	    
		$name = $_POST['name'];
		$houseNumber = $_POST['houseNo'];
		$email = $_POST['email'];
		$phoneNo = $_POST['phoneNo'];
		$password = $_POST['pass'];
		mysqli_query($db, "INSERT INTO resident (name, houseNumber, email, phoneNo, password) VALUES ('$name','$houseNumber', '$email', '$phoneNo', '$password')"); 
	            echo '<script language="javascript">';
                echo 'alert("Welcome to Your New eNyumba Account! Login to Continue")';
                echo '</script>';
				echo "<script>location.href='../html/login.html';</script>";	 
}

 ?>