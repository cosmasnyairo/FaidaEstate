<?php
     session_start();
     $db = mysqli_connect('localhost', 'root', '', 'estate');
   
	$update = false;
 
      if(isset($_POST['save'])) {
	    
		
		$month = $_POST['month'];
		$security = $_POST['security'];
		$garbage = $_POST['garbage'];
		$infrastructure = $_POST['infrastructure'];
		$total = $_POST['total'];
		
		mysqli_query($db, "INSERT INTO statement (month, security, garbage, infrastructure, total) VALUES ('$month' ,'$security', '$garbage', '$infrastructure' , '$total')"); 
	            echo '<script language="javascript">';
                echo 'alert("Your Statement has been Added!")';
                echo '</script>';
				echo "<script>location.href='../html/receipt.html';</script>";

	 
}

 ?>