// JavaScript Document

	$('.carousel').carousel();
	