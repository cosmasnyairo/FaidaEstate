<?php
// check request
if(isset($_POST['residentID']) && isset($_POST['residentID']) != "")
{
    // include Database connection file
    include("db_connection.php");

    // get user id
    $residentID = $_POST['residentID'];

    // delete User
    $query = "DELETE FROM resident WHERE residentID = '$residentID'";
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
}
?>